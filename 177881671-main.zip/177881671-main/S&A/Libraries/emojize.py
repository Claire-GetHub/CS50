import emoji

#Gets input, adds out put to it, emmojizes it, then prints
print(emoji.emojize(f"Output: {input("Input: ")}", language='alias'))
