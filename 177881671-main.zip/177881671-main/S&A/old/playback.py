x = input("playback ").replace(" ", "...")
print(x)
