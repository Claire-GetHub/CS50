x = input('').lower()
print(x)

