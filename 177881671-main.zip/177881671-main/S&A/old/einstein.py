
m = int(input("M: "))

energy = m * 300000000**2
print(f'E: {energy}')
