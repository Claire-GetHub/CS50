import twttr

def test_test ():
     assert twttr.shorten("helloH3O,") == "hllH3,"


